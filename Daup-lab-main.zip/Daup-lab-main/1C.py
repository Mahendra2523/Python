str = "Hello" 
arr = list(str) 
print(arr) 
print(arr[3]) 
