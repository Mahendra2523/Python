numbers = eval(input("Enter list:")) 
largest = max(numbers) 
print("The largest number in the list is:", largest)
