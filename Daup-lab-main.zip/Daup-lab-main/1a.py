val=int(input("Enter the weight into kilograms")) 
result=val*2.2 
print(f"{val}kgs in pounds is {result}pounds") 
