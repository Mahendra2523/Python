for n in range(8,90,3):
  print(n,end=" ")
